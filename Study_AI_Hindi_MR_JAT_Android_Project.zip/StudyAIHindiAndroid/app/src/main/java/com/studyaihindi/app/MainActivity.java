package com.studyaihindi.app;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.*;import android.view.*;import android.view.animation.*;import android.widget.*;import java.io.*;import java.util.*;import org.json.*;

public class MainActivity extends Activity {
  final int BG=Color.rgb(8,20,38), PANEL=Color.rgb(16,31,53), BLUE=Color.rgb(79,140,255), WHITE=Color.WHITE, MUTED=Color.rgb(174,190,212), GREEN=Color.rgb(39,199,139), RED=Color.rgb(255,99,118);
  LinearLayout root; ArrayList<Q> bank=new ArrayList<>(); int[] answers=new int[50]; int index=0, seconds=1800; boolean finished=false; Handler handler=new Handler(); TextView timerView; Runnable tick; long startTime; String lastResult="";
  class Q {String subject, question, explanation; String[] options; int answer; Q(String s,String q,String a,String b,String c,String d,int correct,String e){subject=s;question=q;options=new String[]{a,b,c,d};answer=correct;explanation=e;}}
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);loadQuestions();Arrays.fill(answers,-1);showSplash();}
  void loadQuestions(){
    add("GK","भारत की राजधानी कौन-सी है?","मुंबई","नई दिल्ली","जयपुर","लखनऊ",1,"भारत की राजधानी नई दिल्ली है।");
    add("Science","पौधे भोजन बनाने के लिए किस प्रक्रिया का उपयोग करते हैं?","श्वसन","प्रकाश संश्लेषण","पाचन","उत्सर्जन",1,"प्रकाश संश्लेषण में पौधे सूर्य के प्रकाश की सहायता से भोजन बनाते हैं।");
    add("Maths","25 का 20% कितना है?","2","4","5","10",2,"25 × 20 ÷ 100 = 5।");
    add("Reasoning","श्रृंखला पूरी करें: 2, 4, 8, 16, __","18","24","30","32",3,"हर बार संख्या दोगुनी हो रही है; 16 × 2 = 32।");
    add("Hindi","‘जल’ का समानार्थी शब्द कौन-सा है?","अग्नि","नीर","पवन","गगन",1,"‘नीर’ जल का समानार्थी शब्द है।");
    add("English","Choose the plural of ‘child’. ","childs","childes","children","childrens",2,"The plural of child is children.");
    add("GK","भारत का राष्ट्रीय पशु कौन-सा है?","शेर","बाघ","हाथी","चीतल",1,"भारत का राष्ट्रीय पशु बाघ है।");
    add("Science","पानी का रासायनिक सूत्र क्या है?","CO₂","O₂","H₂O","NaCl",2,"पानी का रासायनिक सूत्र H₂O है।");
    add("Maths","12 × 8 = ?","86","92","96","108",2,"12 × 8 = 96।");
    add("Reasoning","यदि CAT को DBU लिखा जाए, तो DOG कैसे लिखा जाएगा?","EPH","EOG","DPH","FPH",0,"हर अक्षर के अगले अक्षर से बदला गया है: D→E, O→P, G→H।");
    add("GK","भारतीय संविधान कब लागू हुआ?","15 अगस्त 1947","26 जनवरी 1950","26 नवंबर 1949","2 अक्टूबर 1950",1,"संविधान 26 जनवरी 1950 को लागू हुआ।");
    add("Science","रक्त को पूरे शरीर में पंप करने वाला अंग कौन-सा है?","फेफड़ा","गुर्दा","हृदय","यकृत",2,"हृदय रक्त को पूरे शरीर में पंप करता है।");
    add("Maths","15 + 27 = ?","32","42","41","43",1,"15 + 27 = 42।");
    add("Reasoning","श्रृंखला: 5, 10, 15, 20, __","22","24","25","30",2,"हर बार 5 जोड़ा जा रहा है, इसलिए उत्तर 25 है।");
    add("Hindi","‘दिन’ का विलोम शब्द क्या है?","सुबह","रात","प्रकाश","समय",1,"दिन का विलोम रात है।");
    add("English","Opposite of ‘hot’ is:","warm","cold","heat","boil",1,"Hot का opposite cold है।");
    add("GK","राजस्थान की राजधानी कौन-सी है?","जोधपुर","उदयपुर","जयपुर","कोटा",2,"राजस्थान की राजधानी जयपुर है।");
    add("Science","सूर्य के सबसे निकट ग्रह कौन-सा है?","शुक्र","पृथ्वी","मंगल","बुध",3,"बुध सूर्य के सबसे निकट ग्रह है।");
    add("Maths","एक दर्जन में कितनी वस्तुएँ होती हैं?","10","12","15","20",1,"एक दर्जन में 12 वस्तुएँ होती हैं।");
    add("Reasoning","विषम चुनें।","सेब","आम","गाजर","केला",2,"गाजर सब्ज़ी है; बाकी सामान्यतः फल हैं।");
    add("GK","भारत का राष्ट्रीय पक्षी कौन-सा है?","मोर","तोता","हंस","कबूतर",0,"भारत का राष्ट्रीय पक्षी भारतीय मोर है।");
    add("Science","सामान्य वायुदाब पर पानी कितने °C पर उबलता है?","50°C","75°C","100°C","120°C",2,"समुद्र तल के सामान्य वायुदाब पर पानी 100°C पर उबलता है।");
    add("Maths","144 का वर्गमूल क्या है?","10","11","12","14",2,"12 × 12 = 144, इसलिए वर्गमूल 12 है।");
    add("Reasoning","यदि आज सोमवार है, तो 3 दिन बाद कौन-सा दिन होगा?","मंगलवार","बुधवार","गुरुवार","शुक्रवार",2,"सोमवार के 3 दिन बाद गुरुवार होगा।");
    add("Hindi","‘सुंदर’ का विलोम क्या है?","अच्छा","कुरूप","मधुर","सरल",1,"सुंदर का विलोम कुरूप है।");
    add("English","Choose the correct article: ___ apple","A","An","Thee","No article always",1,"Apple की शुरुआत vowel sound से होती है, इसलिए ‘an apple’ सही है।");
    add("GK","भारत का राष्ट्रीय गान किसने लिखा?","प्रेमचंद","रवींद्रनाथ टैगोर","महात्मा गांधी","बंकिमचंद्र चट्टोपाध्याय",1,"‘जन गण मन’ रवींद्रनाथ टैगोर ने लिखा था।");
    add("Science","मनुष्य सांस लेने के लिए मुख्यतः कौन-सी गैस उपयोग करता है?","नाइट्रोजन","ऑक्सीजन","कार्बन डाइऑक्साइड","हीलियम",1,"शरीर की कोशिकाएँ ऊर्जा प्राप्त करने की प्रक्रिया में ऑक्सीजन का उपयोग करती हैं।");
    add("Maths","200 का 15% कितना है?","15","20","30","35",2,"200 × 15 ÷ 100 = 30।");
    add("Reasoning","श्रृंखला: 1, 4, 9, 16, __","20","24","25","36",2,"ये क्रमशः 1², 2², 3², 4² हैं; अगला 5² = 25 है।");
    add("GK","भारत की मुद्रा क्या है?","टका","रुपया","दीनार","युआन",1,"भारत की मुद्रा भारतीय रुपया है।");
    add("Science","पौधों में हरा रंग किस वर्णक के कारण होता है?","हीमोग्लोबिन","क्लोरोफिल","मेलानिन","केराटिन",1,"क्लोरोफिल पौधों को हरा रंग देता है और प्रकाश संश्लेषण में मदद करता है।");
    add("Maths","7² का मान क्या है?","14","42","49","56",2,"7² = 7 × 7 = 49।");
    add("Reasoning","अक्षर क्रम में C के बाद कौन-सा अक्षर आता है?","A","B","D","E",2,"अंग्रेज़ी वर्णमाला में C के बाद D आता है।");
    add("Hindi","‘आकाश’ का समानार्थी शब्द कौन-सा है?","गगन","पाताल","धरती","सागर",0,"गगन, आकाश का समानार्थी शब्द है।");
    add("English","Past tense of ‘go’ is:","goed","gone","went","going",2,"Go का simple past tense went है।");
    add("GK","भारत का स्वतंत्रता दिवस कब मनाया जाता है?","26 जनवरी","15 अगस्त","2 अक्टूबर","14 नवंबर",1,"भारत का स्वतंत्रता दिवस 15 अगस्त को मनाया जाता है।");
    add("Science","पृथ्वी का प्राकृतिक उपग्रह कौन-सा है?","मंगल","सूर्य","चंद्रमा","शुक्र",2,"चंद्रमा पृथ्वी का प्राकृतिक उपग्रह है।");
    add("Maths","एक घंटे में कितने मिनट होते हैं?","30","45","60","100",2,"एक घंटे में 60 मिनट होते हैं।");
    add("Reasoning","विषम संख्या चुनें।","2","4","7","8",2,"7 विषम संख्या है; बाकी सभी सम संख्याएँ हैं।");
    add("GK","भारत के पहले प्रधानमंत्री कौन थे?","सरदार पटेल","जवाहरलाल नेहरू","डॉ. राजेंद्र प्रसाद","लाल बहादुर शास्त्री",1,"जवाहरलाल नेहरू भारत के पहले प्रधानमंत्री थे।");
    add("Science","मानव शरीर का सबसे बड़ा बाहरी अंग कौन-सा है?","हृदय","त्वचा","यकृत","फेफड़ा",1,"त्वचा मानव शरीर का सबसे बड़ा अंग है।");
    add("Maths","50 ÷ 5 = ?","5","10","15","20",1,"50 ÷ 5 = 10।");
    add("Reasoning","यदि सभी गुलाब फूल हैं, तो कौन-सा कथन निश्चित है?","सभी फूल गुलाब हैं","गुलाब फूल हैं","कोई गुलाब फूल नहीं","सभी फूल लाल हैं",1,"दिए गए कथन से निश्चित रूप से केवल यही निकलता है कि गुलाब फूल हैं।");
    add("Hindi","‘विद्यालय’ का अर्थ क्या है?","अस्पताल","स्कूल","बाज़ार","कार्यालय",1,"विद्यालय का अर्थ पढ़ने-लिखने का स्थान यानी स्कूल है।");
    add("English","Meaning of ‘quick’ is:","slow","fast","late","weak",1,"Quick का अर्थ fast यानी तेज़ होता है।");
    add("GK","क्षेत्रफल की दृष्टि से भारत का सबसे बड़ा राज्य कौन-सा है?","उत्तर प्रदेश","मध्य प्रदेश","राजस्थान","महाराष्ट्र",2,"क्षेत्रफल के आधार पर राजस्थान भारत का सबसे बड़ा राज्य है।");
    add("Science","सूर्य से हमें मुख्यतः क्या प्राप्त होता है?","प्रकाश और ऊष्मा","केवल ध्वनि","केवल मिट्टी","नमक",0,"सूर्य पृथ्वी को प्रकाश और ऊष्मा देता है।");
    add("Maths","9 × 9 = ?","72","81","89","99",1,"9 × 9 = 81।");
    add("Reasoning","श्रृंखला: 10, 20, 30, 40, __","45","50","55","60",1,"हर बार 10 बढ़ रहा है, इसलिए अगली संख्या 50 है।");
  }
  void add(String s,String q,String a,String b,String c,String d,int correct,String e){bank.add(new Q(s,q,a,b,c,d,correct,e));}
  int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);} 
  TextView text(String t,int size,int color){TextView v=new TextView(this);v.setText(t);v.setTextSize(size);v.setTextColor(color);v.setPadding(dp(2),dp(6),dp(2),dp(6));return v;}
  LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(18),dp(16),dp(18),dp(22));l.setBackgroundColor(BG);return l;}
  void base(){root=col();ScrollView sc=new ScrollView(this);sc.addView(root);setContentView(sc);}
  Button button(String label,LinearLayout target,Runnable action){Button b=new Button(this);b.setText(label);b.setTextColor(WHITE);b.setAllCaps(false);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(BLUE));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(7),0,dp(7));target.addView(b,p);b.setOnClickListener(v->action.run());return b;}
  void showSplash(){base();root.setGravity(Gravity.CENTER);TextView title=text("Study AI Hindi",30,WHITE);title.setGravity(17);root.addView(title);TextView brand=text("MR JAT",42,Color.rgb(255,205,80));brand.setGravity(17);brand.setTypeface(null,1);root.addView(brand);TextView sub=text("तैयारी आज, सफलता कल।",18,MUTED);sub.setGravity(17);root.addView(sub);TextView loading=text("आपका टेस्ट ऐप तैयार हो रहा है…",14,MUTED);loading.setGravity(17);root.addView(loading);handler.postDelayed(this::home,3000);}
  void home(){base();TextView title=text("Study AI Hindi",30,WHITE);title.setGravity(17);root.addView(title);TextView brand=text("MR JAT",36,Color.rgb(255,205,80));brand.setGravity(17);brand.setTypeface(null,1);root.addView(brand);TextView desc=text("सरकारी भर्ती अभ्यास टेस्ट",17,MUTED);desc.setGravity(17);root.addView(desc);TextView info=text("50 सवाल  •  30 मिनट  •  गलत उत्तर −0.33 अंक\nMaths · Reasoning · GK · Science · Hindi · English",15,MUTED);info.setGravity(17);root.addView(info);button("नया टेस्ट शुरू करें",root,()->startTest());button("पिछले टेस्ट और रिजल्ट देखें",root,()->history());TextView note=text("टेस्ट पूरा होने पर उत्तर और सॉल्यूशन सेव होंगे।",13,MUTED);note.setGravity(17);root.addView(note);}
  void showMrJatPopup(Runnable after){
    final Dialog dialog=new Dialog(this);
    LinearLayout screen=new LinearLayout(this);screen.setOrientation(LinearLayout.VERTICAL);screen.setGravity(Gravity.CENTER);screen.setBackgroundColor(Color.rgb(3,8,20));
    TextView small=text("ANSWER LOCKED",16,MUTED);small.setGravity(Gravity.CENTER);screen.addView(small);
    TextView name=text("MR JAT",54,Color.rgb(255,205,80));name.setGravity(Gravity.CENTER);name.setTypeface(null,1);name.setShadowLayer(dp(18),0,0,Color.rgb(79,140,255));screen.addView(name);
    TextView sub=text("NEXT LEVEL • KEEP GOING",14,WHITE);sub.setGravity(Gravity.CENTER);screen.addView(sub);
    dialog.setContentView(screen);Window w=dialog.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout(-1,-1);w.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);}
    dialog.setCancelable(false);dialog.show();if(dialog.getWindow()!=null){dialog.getWindow().setLayout(-1,-1);dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);}
    ScaleAnimation pulse=new ScaleAnimation(.55f,1f,.55f,1f,Animation.RELATIVE_TO_SELF,.5f,Animation.RELATIVE_TO_SELF,.5f);pulse.setDuration(420);pulse.setInterpolator(new OvershootInterpolator());name.startAnimation(pulse);
    handler.postDelayed(()->{if(!isFinishing()&&dialog.isShowing())dialog.dismiss();if(!isFinishing())after.run();},1250);
  }
  void pickPhoto(){}
  @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);}
  void startTest(){Arrays.fill(answers,-1);index=0;seconds=1800;finished=false;startTime=System.currentTimeMillis();showQuestion();startTimer();}
  void startTimer(){if(tick!=null)handler.removeCallbacks(tick);tick=new Runnable(){public void run(){if(finished)return;long elapsed=(System.currentTimeMillis()-startTime)/1000;seconds=(int)Math.max(0,1800-elapsed);if(timerView!=null)timerView.setText(String.format(Locale.getDefault(),"⏱ %02d:%02d",seconds/60,seconds%60));if(seconds<=0){finishTest(true);return;}handler.postDelayed(this,1000);}};handler.post(tick);}
  void showQuestion(){base();Q q=bank.get(index);TextView top=text("सवाल "+(index+1)+" / 50                              "+q.subject,16,MUTED);root.addView(top);timerView=text("⏱ 30:00",18,seconds<300?RED:WHITE);root.addView(timerView);TextView progress=text("उत्तर दिए: "+answered()+" / 50",14,MUTED);root.addView(progress);TextView question=text(q.question,23,WHITE);question.setPadding(0,dp(25),0,dp(20));root.addView(question);for(int i=0;i<4;i++){final int choice=i;Button b=new Button(this);b.setAllCaps(false);b.setText(""+"ABCD".charAt(i)+".  "+q.options[i]+(answers[index]==i?"   ✓":""));b.setTextColor(WHITE);b.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(answers[index]==i?Color.rgb(35,76,122):PANEL));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(5),0,dp(5));root.addView(b,p);b.setOnClickListener(v->{answers[index]=choice;final int current=index;showMrJatPopup(()->{if(!finished&&index==current)showQuestion();});});}LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);root.addView(row);smallButton("← पिछला",row,()->{if(index>0){index--;showQuestion();}});smallButton("अगला →",row,()->{if(index<49){index++;showQuestion();}});button("सवालों की सूची",root,()->questionGrid());button("टेस्ट सबमिट करें",root,()->new AlertDialog.Builder(this).setTitle("टेस्ट सबमिट करें?").setMessage("सबमिट करने के बाद जवाब बदले नहीं जा सकेंगे।").setNegativeButton("वापस",null).setPositiveButton("सबमिट",(d,w)->finishTest(false)).show());}
  int answered(){int n=0;for(int a:answers)if(a!=-1)n++;return n;}
  void smallButton(String t,LinearLayout row,Runnable r){Button b=new Button(this);b.setText(t);b.setAllCaps(false);b.setTextColor(WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(36,59,89)));row.addView(b,new LinearLayout.LayoutParams(0,-2,1));b.setOnClickListener(v->r.run());}
  void questionGrid(){base();root.addView(text("सवाल चुनें",26,WHITE));for(int i=0;i<50;i++){final int j=i;button((i+1)+". "+(answers[i]<0?"उत्तर नहीं दिया":"उत्तर चुना"),root,()->{index=j;showQuestion();});}button("टेस्ट पर लौटें",root,()->showQuestion());}
  void finishTest(boolean auto){if(finished)return;finished=true;handler.removeCallbacks(tick);int correct=0,wrong=0,skip=0;for(int i=0;i<50;i++){if(answers[i]<0)skip++;else if(answers[i]==bank.get(i).answer)correct++;else wrong++;}double neg=wrong*.33,score=correct-neg;JSONObject rec=new JSONObject();try{rec.put("date",new java.text.SimpleDateFormat("dd-MM-yyyy HH:mm",Locale.getDefault()).format(new Date()));rec.put("correct",correct);rec.put("wrong",wrong);rec.put("skip",skip);rec.put("negative",neg);rec.put("score",score);JSONArray arr=new JSONArray();for(int a:answers)arr.put(a);rec.put("answers",arr);JSONArray hist=new JSONArray(getPreferences(0).getString("history","[]"));hist.put(rec);getPreferences(0).edit().putString("history",hist.toString()).apply();lastResult=rec.toString();}catch(Exception ignored){}showResult(correct,wrong,skip,neg,score,auto);}
  void showResult(int correct,int wrong,int skip,double neg,double score,boolean auto){base();root.addView(text("टेस्ट रिजल्ट",30,WHITE));root.addView(text("अंतिम स्कोर: "+String.format(Locale.getDefault(),"%.2f / 50",score),24,WHITE));root.addView(text("सही उत्तर: "+correct+"\nगलत उत्तर: "+wrong+"\nछोड़े गए: "+skip+"\nनेगेटिव मार्क्स: −"+String.format(Locale.getDefault(),"%.2f",neg)+"\nAccuracy: "+(answered()==0?0:Math.round(correct*100f/answered()))+"%",18,MUTED));button("सभी सवालों के सॉल्यूशन देखें",root,()->review());button("होम स्क्रीन",root,()->home());button("टेस्ट हिस्ट्री",root,()->history());}
  void review(){base();root.addView(text("उत्तर और सॉल्यूशन",28,WHITE));for(int i=0;i<50;i++){Q q=bank.get(i);LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(12),dp(10),dp(12),dp(10));box.setBackgroundColor(PANEL);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.setMargins(0,dp(5),0,dp(5));root.addView(box,bp);box.addView(text((i+1)+". "+q.question,17,WHITE));int a=answers[i];box.addView(text("आपका उत्तर: "+(a<0?"नहीं दिया":""+"ABCD".charAt(a)+". "+q.options[a]),14,a==q.answer?GREEN:RED));box.addView(text("सही उत्तर: "+"ABCD".charAt(q.answer)+". "+q.options[q.answer],14,GREEN));box.addView(text("समाधान: "+q.explanation,14,MUTED));}button("रिजल्ट पर वापस",root,()->{int c=0,w=0,s=0;for(int i=0;i<50;i++){if(answers[i]<0)s++;else if(answers[i]==bank.get(i).answer)c++;else w++;}showResult(c,w,s,w*.33,c-w*.33,false);});}
  void history(){base();root.addView(text("पिछले टेस्ट",28,WHITE));try{JSONArray h=new JSONArray(getPreferences(0).getString("history","[]"));if(h.length()==0)root.addView(text("अभी कोई टेस्ट सेव नहीं है। पहला टेस्ट पूरा करो।",16,MUTED));for(int i=h.length()-1;i>=0;i--){final JSONObject o=h.getJSONObject(i);button(o.optString("date")+"\nस्कोर: "+String.format(Locale.getDefault(),"%.2f",o.optDouble("score"))+" / 50  •  सही "+o.optInt("correct")+"  •  गलत "+o.optInt("wrong")+"  •  छोड़े "+o.optInt("skip")+"\nइस टेस्ट के उत्तर/सॉल्यूशन देखें",root,()->{try{JSONArray aa=o.getJSONArray("answers");for(int k=0;k<50;k++)answers[k]=aa.optInt(k,-1);review();}catch(Exception ex){Toast.makeText(this,"इस टेस्ट का डेटा नहीं खुला",Toast.LENGTH_SHORT).show();}});}}catch(Exception ignored){}button("होम स्क्रीन",root,()->home());}
  @Override public void onBackPressed(){if(!finished&&tick!=null){new AlertDialog.Builder(this).setMessage("टेस्ट चल रहा है। बाहर जाने पर समय चलता रहेगा।").setNegativeButton("टेस्ट पर लौटें",null).setPositiveButton("होम",(d,w)->home()).show();}else home();}
}
